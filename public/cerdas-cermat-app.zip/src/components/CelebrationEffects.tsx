import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';

export default function CelebrationEffects({ trigger }: { trigger: boolean }) {
  useEffect(() => {
    if (!trigger) return;
    
    // Launch confetti from multiple angles
    var duration = 2.5 * 1000;
    var animationEnd = Date.now() + duration;
    var defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    var interval: any = setInterval(function() {
      var timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      var particleCount = 50 * (timeLeft / duration);
      
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
      });
    }, 250);

    return () => {
      clearInterval(interval);
      confetti.reset();
    };
  }, [trigger]);

  return null;
}
